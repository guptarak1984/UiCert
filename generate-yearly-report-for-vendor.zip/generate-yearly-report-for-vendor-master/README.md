# generate-yearly-report-for-vendor
UiPath Level 3 - Advanced Training [v.2019.7]
